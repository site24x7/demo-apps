"""Central chaos engine that coordinates fault injection.

Thread-safety model
-------------------
* ``_active_rules`` is a plain list that is *replaced atomically* (copy-on-write)
  behind a :class:`threading.Lock`.
* Request-handling threads call :meth:`find_matching_rules` and
  :meth:`should_fire` which only *read* the list reference — no lock needed
  because Python's GIL guarantees reference reads are atomic.
* The :class:`ConfigFileWatcher` thread calls :meth:`_on_config_update` which
  acquires the lock, builds a new list, and swaps the reference.
"""

from __future__ import annotations

import logging
import os
import re as _re
import threading
import time
from typing import Callable, Dict, List, Optional

from .config import ConfigFileWatcher, HeartbeatWriter
from .health import is_excluded
from .models import AppFaultConfig, FaultRuleConfig
from .probability import ProbabilityEngine
from .uds import (
    _DEFAULT_HEALTH_INTERVAL_S,
    _DEFAULT_SOCKET_PATH,
    UDSClient,
    current_hostname,
    detect_db_drivers,
)

logger = logging.getLogger("site24x7_chaos.engine")

# Default config directory (where the agent writes fault configs)
_DEFAULT_CONFIG_DIR = "/var/site24x7-labs/faults"
_DEFAULT_POLL_INTERVAL_S = 2.0
# v2: agent Unix Domain Socket defaults
_DEFAULT_UDS_PATH = _DEFAULT_SOCKET_PATH
_DEFAULT_UDS_HEALTH_INTERVAL_MS = int(_DEFAULT_HEALTH_INTERVAL_S * 1000)


class ChaosEngine:
    """Singleton-style engine that manages fault rules and the config watcher.

    Parameters
    ----------
    enabled:
        Master kill-switch.  ``False`` disables all fault injection.
    app_name:
        Application name — must match the ``app_name`` in the config file
        written by the agent.
    config_dir:
        Directory where the agent writes ``{app_name}.json``.
    poll_interval_s:
        How often (seconds) the watcher checks for file changes.
    """

    def __init__(
        self,
        enabled: bool = True,
        app_name: str = "",
        config_dir: str = "",
        poll_interval_s: float = _DEFAULT_POLL_INTERVAL_S,
        framework: str = "",
        framework_version: str = "",
        uds_enabled: bool = True,
        uds_path: str = "",
        uds_health_interval_ms: int = _DEFAULT_UDS_HEALTH_INTERVAL_MS,
    ) -> None:
        # Env var overrides the explicit arg only when the arg is default (True).
        # If caller explicitly passes enabled=False, that wins.
        if not enabled:
            self._enabled = False
        else:
            self._enabled = _env_bool("CHAOS_SDK_ENABLED", True)

        self._app_name = app_name or os.environ.get("CHAOS_SDK_APP_NAME", "")
        self._config_dir = config_dir or os.environ.get("CHAOS_SDK_CONFIG_DIR", _DEFAULT_CONFIG_DIR)
        self._poll_interval_s = poll_interval_s
        self._framework = framework
        self._framework_version = framework_version

        # v2 UDS options (env overrides allowed, matching existing patterns).
        self._uds_enabled = uds_enabled and _env_bool("CHAOS_SDK_UDS_ENABLED", True)
        self._uds_path = (
            uds_path
            or os.environ.get("CHAOS_SDK_UDS_PATH", "")
            or _DEFAULT_UDS_PATH
        )
        self._uds_health_interval_ms = _env_int(
            "CHAOS_SDK_UDS_HEALTH_INTERVAL_MS", uds_health_interval_ms
        )

        # Thread-safe active rules (copy-on-write)
        self._lock = threading.Lock()
        self._active_rules: List[FaultRuleConfig] = []

        # Onset-shaping probability engine (replaces raw random.random()).
        self._probability = ProbabilityEngine()

        # Lightweight health counters for the UDS health report.
        self._request_count = 0
        self._fault_count = 0
        self._counter_lock = threading.Lock()
        self._start_time = time.time()

        # Config update listeners (e.g., ResourceFaultInjector)
        self._config_listeners: List[Callable[[], None]] = []

        # Watcher (created on start)
        self._watcher: Optional[ConfigFileWatcher] = None

        # Heartbeat writer (created on start)
        self._heartbeat: Optional[HeartbeatWriter] = None

        # UDS client (created on start)
        self._uds: Optional[UDSClient] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the config file watcher daemon thread."""
        if not self._enabled:
            logger.info("Chaos SDK is disabled")
            return

        if not self._app_name:
            logger.warning("CHAOS_SDK_APP_NAME not set, fault injection disabled")
            return

        config_file = os.path.join(self._config_dir, f"{self._app_name}.json")
        self._watcher = ConfigFileWatcher(
            config_file=config_file,
            listener=self._on_config_update,
            poll_interval_s=self._poll_interval_s,
        )
        self._watcher.start()
        logger.info(
            "ChaosEngine started for app '%s', config file: %s",
            self._app_name,
            config_file,
        )

        # Start heartbeat writer so the agent can detect SDK presence
        from . import __version__ as sdk_version

        self._heartbeat = HeartbeatWriter(
            config_dir=self._config_dir,
            app_name=self._app_name,
            sdk_version=sdk_version,
            framework=self._framework,
            framework_version=self._framework_version,
        )
        self._heartbeat.start()

        # v2: connect to the agent over UDS for instant config push + health
        # reporting. The file watcher above remains active as a fallback.
        if self._uds_enabled:
            self._start_uds_client(sdk_version)

    def _start_uds_client(self, sdk_version: str) -> None:
        """Start the UDS client daemon thread. Never let UDS setup break the
        app — file polling remains a working fallback."""
        try:
            self._uds = UDSClient(
                socket_path=self._uds_path,
                instance_id=self._instance_id(),
                app_name=self._app_name,
                version=sdk_version,
                hostname=current_hostname(),
                pid=os.getpid(),
                db_drivers=detect_db_drivers(),
                on_config=self._on_config_update,
                on_kill=self._on_kill,
                health_supplier=self._health_snapshot,
                health_interval_s=self._uds_health_interval_ms / 1000.0,
            )
            self._uds.start()
            logger.info("Chaos UDS client started, socket: %s", self._uds_path)
        except Exception:
            logger.warning(
                "Failed to start UDS client, falling back to file polling",
                exc_info=True,
            )

    def stop(self) -> None:
        """Stop the UDS client, config file watcher and heartbeat writer."""
        if self._uds is not None:
            self._uds.stop()
            self._uds = None
        if self._heartbeat is not None:
            self._heartbeat.stop()
            self._heartbeat = None
        if self._watcher is not None:
            self._watcher.stop()
            self._watcher = None
        logger.info("ChaosEngine stopped")

    # ------------------------------------------------------------------
    # Config update
    # ------------------------------------------------------------------

    def _on_config_update(self, config: AppFaultConfig) -> None:
        """Called by ConfigFileWatcher (file fallback) and the UDS client when a
        new config arrives."""
        enabled_rules = [r for r in config.rules if r.enabled]
        with self._lock:
            self._active_rules = enabled_rules
        # Drop probability ramp/burst state for rules no longer present so a
        # re-added rule restarts its onset cleanly.
        self._probability.retain_only(
            (r.id or r.fault_type) for r in enabled_rules
        )
        logger.debug("Active rules updated: %d rules", len(enabled_rules))

        # Notify listeners (e.g., ResourceFaultInjector triggers on config change)
        for listener in self._config_listeners:
            try:
                listener()
            except Exception:
                logger.error("Config update listener error", exc_info=True)

    def _on_kill(self) -> None:
        """Agent pushed a kill command over UDS: drop all active rules now."""
        with self._lock:
            self._active_rules = []
        self._probability.retain_only(())
        logger.warning("Kill switch received over UDS — all fault rules cleared")
        for listener in self._config_listeners:
            try:
                listener()
            except Exception:
                logger.error("Config update listener error on kill", exc_info=True)

    def add_config_update_listener(self, listener: Callable[[], None]) -> None:
        """Register a callback invoked whenever active rules are updated.

        Used by resource fault injectors that trigger on config changes
        (not on every request).

        If rules were already loaded before this listener was registered
        (race condition where ConfigFileWatcher fires before
        ResourceFaultInjector.install()), the listener is invoked immediately
        so it doesn't miss the initial config.
        """
        self._config_listeners.append(listener)

        # If rules were already loaded before this listener was registered,
        # invoke it immediately so it doesn't miss the initial config.
        if self._active_rules:
            logger.info(
                "Invoking new config listener immediately — %d active rules already loaded",
                len(self._active_rules),
            )
            try:
                listener()
            except Exception:
                logger.error("Config update listener error on immediate invocation", exc_info=True)

    # ------------------------------------------------------------------
    # Rule matching
    # ------------------------------------------------------------------

    def find_matching_rules(
        self,
        fault_type_prefix: str,
        request_url: str = "",
    ) -> List[FaultRuleConfig]:
        """Return all active rules whose ``fault_type`` starts with *prefix*
        and whose ``url_pattern`` matches *request_url*.
        """
        if not self._enabled:
            return []

        rules = self._active_rules  # single atomic read
        if not rules:
            return []

        # Health, readiness, and observability endpoints are NEVER faulted —
        # doing so would let monitoring/orchestration detect or react to the
        # synthetic failure. This exclusion is non-negotiable.
        if request_url and is_excluded(request_url):
            return []

        with self._counter_lock:
            self._request_count += 1

        return [
            r
            for r in rules
            if r.fault_type.startswith(fault_type_prefix)
            and _matches_url(r.url_pattern, request_url)
        ]

    def should_fire(self, rule: FaultRuleConfig) -> bool:
        """Check whether the fault should actually fire.

        Delegates to the :class:`ProbabilityEngine` so that gradual-ramp and
        burst onset shaping are applied on top of the rule's base probability.
        """
        fire = self._probability.should_fire(rule)
        if fire:
            with self._counter_lock:
                self._fault_count += 1
        return fire

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def app_name(self) -> str:
        return self._app_name

    @property
    def active_rules(self) -> List[FaultRuleConfig]:
        return self._active_rules

    # ------------------------------------------------------------------
    # v2 UDS support helpers
    # ------------------------------------------------------------------

    def _instance_id(self) -> str:
        """Stable per-process instance id: ``app@host:pid``."""
        return f"{self._app_name}@{current_hostname()}:{os.getpid()}"

    def _health_snapshot(self) -> Dict[str, object]:
        """Lightweight health metrics for the UDS health report."""
        with self._counter_lock:
            requests = self._request_count
            faults = self._fault_count
        fault_rate = (faults / requests) if requests > 0 else 0.0
        return {
            "requests": requests,
            "faults_injected": faults,
            "fault_rate": fault_rate,
            "active_rules": len(self._active_rules),
            "uptime_ms": int((time.time() - self._start_time) * 1000),
        }


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _env_bool(name: str, default: bool) -> bool:
    """Read an environment variable as a boolean."""
    val = os.environ.get(name)
    if val is None:
        return default
    return val.lower() in ("1", "true", "yes", "on")


def _env_int(name: str, default: int) -> int:
    """Read an environment variable as an int, falling back to *default*."""
    val = os.environ.get(name)
    if val is None:
        return default
    try:
        return int(val)
    except ValueError:
        return default


def _matches_url(pattern: str, url: str) -> bool:
    """Simple glob-style URL pattern matching.

    * Empty pattern matches everything.
    * ``*`` matches a single path segment (no slashes).
    * ``**`` matches any number of path segments.
    """
    if not pattern:
        return True
    if not url:
        return True

    # Convert glob to regex
    regex = (
        pattern.replace(".", r"\.")
        .replace("**", "##DOUBLESTAR##")
        .replace("*", "[^/]*")
        .replace("##DOUBLESTAR##", ".*")
    )
    try:
        return bool(_re.fullmatch(regex, url))
    except _re.error:
        logger.warning("Invalid URL pattern '%s'", pattern)
        return False
