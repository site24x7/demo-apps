"""Realistic error pools — per-fault-type pools of real Python exceptions.

When a fault fires without an explicit message/exception in its rule config, the
SDK selects a random, realistic exception from these pools so that an injected
failure is indistinguishable from a genuine production failure: the exception
types are real driver / HTTP-client exceptions and the messages mirror what those
libraries actually emit.

No string in this file contains "chaos", "site24x7", "inject", or any other
marker that would reveal the failure was synthetic.
"""

from __future__ import annotations

import random
from typing import Dict, List, Tuple

# ---------------------------------------------------------------------------
# Template type: (fully-qualified-class-name, message)
# ---------------------------------------------------------------------------
ErrorTemplate = Tuple[str, str]


# --- HTTP / outbound service-call failures (requests / urllib3 style) -------
_HTTP: List[ErrorTemplate] = [
    ("requests.exceptions.ConnectionError",
     "HTTPConnectionPool(host='upstream', port=80): "
     "Max retries exceeded with url: / "
     "(Caused by NewConnectionError('Connection refused'))"),
    ("requests.exceptions.ReadTimeout",
     "HTTPConnectionPool(host='upstream', port=80): Read timed out. (read timeout=30)"),
    ("requests.exceptions.ConnectionError",
     "('Connection aborted.', ConnectionResetError(104, 'Connection reset by peer'))"),
    ("builtins.ConnectionResetError", "[Errno 104] Connection reset by peer"),
]

# --- Per-engine database failures -------------------------------------------
_POSTGRES: List[ErrorTemplate] = [
    ("psycopg2.OperationalError",
     "server closed the connection unexpectedly\n\t"
     "This probably means the server terminated abnormally\n\t"
     "before or while processing the request."),
    ("psycopg2.OperationalError",
     "could not connect to server: Connection refused\n\t"
     "Is the server running on host \"db\" and accepting\n\t"
     "TCP/IP connections on port 5432?"),
]

_MYSQL: List[ErrorTemplate] = [
    ("pymysql.err.OperationalError",
     "(2013, 'Lost connection to MySQL server during query')"),
    ("pymysql.err.OperationalError",
     "(2003, \"Can't connect to MySQL server on 'db' (111)\")"),
]

_MONGO: List[ErrorTemplate] = [
    ("pymongo.errors.ServerSelectionTimeoutError",
     "db:27017: connection timed out, Timeout: 30s"),
    ("pymongo.errors.NetworkTimeout", "db:27017: connection timed out"),
]

_REDIS: List[ErrorTemplate] = [
    ("redis.exceptions.ConnectionError",
     "Error connecting to Redis on db:6379. Connection refused."),
    ("redis.exceptions.TimeoutError", "Timeout connecting to server"),
]

# --- Generic / unknown-driver database fallback -----------------------------
_SQL_GENERIC: List[ErrorTemplate] = [
    ("builtins.ConnectionError", "could not connect to server: Connection refused"),
    ("builtins.OSError", "[Errno 110] Connection timed out"),
]

_DB_POOLS: Dict[str, List[ErrorTemplate]] = {
    "postgresql": _POSTGRES,
    "postgres": _POSTGRES,
    "psycopg2": _POSTGRES,
    "mysql": _MYSQL,
    "mariadb": _MYSQL,
    "pymysql": _MYSQL,
    "mongodb": _MONGO,
    "mongo": _MONGO,
    "pymongo": _MONGO,
    "redis": _REDIS,
}


def _pick(pool: List[ErrorTemplate]) -> ErrorTemplate:
    return pool[random.randrange(len(pool))]


def http_template() -> ErrorTemplate:
    """Pick a random HTTP/outbound error template."""
    return _pick(_HTTP)


def database_template(engine: str = "") -> ErrorTemplate:
    """Pick a random database error template for *engine* (postgresql, mysql,
    mongodb, redis, ...). Falls back to a generic connection error when the
    engine is unknown.
    """
    if engine:
        pool = _DB_POOLS.get(engine.lower())
        if pool is not None:
            return _pick(pool)
    return _pick(_SQL_GENERIC)


# ---------------------------------------------------------------------------
# Resolving a template into a real Python exception instance
# ---------------------------------------------------------------------------

def _resolve_class(class_name: str) -> type:
    """Resolve a dotted exception class name to a Python exception class.

    Driver classes (psycopg2, pymysql, pymongo, redis, requests) are imported
    lazily; if the driver is not installed we fall back to a built-in exception
    whose ``__name__``/message still reads like the real thing.
    """
    if class_name.startswith("builtins."):
        return _builtin(class_name.split(".", 1)[1])

    module_name, _, attr = class_name.rpartition(".")
    try:
        module = __import__(module_name, fromlist=[attr])
        cls = getattr(module, attr)
        if isinstance(cls, type) and issubclass(cls, BaseException):
            return cls
    except Exception:
        pass
    # Driver not installed — fall back to a sensible built-in by category.
    lowered = class_name.lower()
    if "timeout" in lowered:
        return TimeoutError
    if "connection" in lowered or "operational" in lowered or "network" in lowered:
        return ConnectionError
    return RuntimeError


def _builtin(name: str) -> type:
    import builtins

    cls = getattr(builtins, name, RuntimeError)
    if isinstance(cls, type) and issubclass(cls, BaseException):
        return cls
    return RuntimeError


def build_exception(template: ErrorTemplate) -> BaseException:
    """Construct a real exception instance from an :data:`ErrorTemplate`.

    Some driver exceptions take non-trivial constructors; on any failure we fall
    back to ``RuntimeError(message)`` so the host app never breaks.
    """
    class_name, message = template
    exc_class = _resolve_class(class_name)
    try:
        return exc_class(message)
    except Exception:
        return RuntimeError(message)


def http_exception() -> BaseException:
    """A realistic HTTP/outbound exception instance for the default error pool."""
    return build_exception(http_template())


def database_exception(engine: str = "") -> BaseException:
    """A realistic database exception instance for the given *engine*."""
    return build_exception(database_template(engine))
