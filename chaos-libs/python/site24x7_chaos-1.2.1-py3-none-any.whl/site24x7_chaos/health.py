"""Health/readiness/observability path exclusion.

Hard-coded, non-configurable set of endpoints that chaos must never touch.
Faulting these paths would let monitoring systems (and orchestrators) detect
that failures are externally induced — or, worse, trigger pod restarts and mask
the experiment. The exclusion is non-negotiable and intentionally not
configurable.
"""

from __future__ import annotations

# Exact-match excluded paths (lower-cased, no query, no trailing slash).
_EXACT = frozenset(
    {
        "/health",
        "/healthz",
        "/ready",
        "/readyz",
        "/live",
        "/livez",
        "/liveness",
        "/readiness",
        "/_health",
        "/ping",
        "/status",
        "/metrics",
        "/prometheus",
    }
)

# Prefix-match excluded paths (lower-cased).
_PREFIXES = (
    "/actuator",      # Spring Boot Actuator (health, info, metrics, ...)
    "/management",    # common management context path
    "/.well-known",   # probes / discovery
)


def is_excluded(path: str) -> bool:
    """Return ``True`` if *path* is a health/observability endpoint that must be
    excluded from fault injection.

    The path is lower-cased, the query string is stripped, and a trailing slash
    (other than for root ``/``) is removed before matching.
    """
    if not path:
        return False

    p = path.lower()
    q = p.find("?")
    if q >= 0:
        p = p[:q]
    # Normalize a trailing slash (but keep root "/").
    if len(p) > 1 and p.endswith("/"):
        p = p[:-1]

    if p in _EXACT:
        return True

    for prefix in _PREFIXES:
        if p == prefix or p.startswith(prefix + "/"):
            return True

    return False
