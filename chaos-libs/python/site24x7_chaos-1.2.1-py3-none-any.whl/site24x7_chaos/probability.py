"""Probability engine — effective firing probability with onset shaping.

Computes the *effective* firing probability for a fault rule at the moment it is
evaluated, so that injected failures ramp in naturally instead of switching on at
full rate. Two onset shapes are supported via the rule config:

* ``gradual`` — probability ramps linearly from ``start_probability`` (default 0)
  to the rule's base probability over ``ramp_seconds`` (default 60), measured from
  the first time the rule was seen.
* ``bursty`` — the base probability is multiplied by ``burst_factor`` (default 2)
  during deterministic burst windows, emulating intermittent spikes rather than a
  constant failure rate.

When no onset is configured the rule's base probability is used unchanged. The
engine tracks each rule's first-seen time keyed by rule id; this state is cleared
automatically when a rule disappears from config (see :meth:`retain_only`).
"""

from __future__ import annotations

import random
import threading
import time
from typing import Callable, Dict, Iterable

from .models import FaultRuleConfig


class ProbabilityEngine:
    """Thread-safe effective-probability calculator with onset shaping."""

    def __init__(self, clock: Callable[[], float] = time.time) -> None:
        # clock returns seconds (float). Seam for deterministic testing.
        self._clock = clock
        self._lock = threading.Lock()
        self._first_seen: Dict[str, float] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def should_fire(self, rule: FaultRuleConfig) -> bool:
        """Decide whether *rule* should fire right now, applying any gradual ramp
        or burst shaping on top of the rule's base probability."""
        p = self.effective_probability(rule, self._clock())
        if p >= 1.0:
            return True
        if p <= 0.0:
            return False
        return random.random() < p

    def effective_probability(self, rule: FaultRuleConfig, now_seconds: float) -> float:
        """Compute the effective probability for *rule* at *now_seconds*.

        Exposed for deterministic testing.
        """
        base = float(rule.probability)
        config = rule.config or {}
        onset = _str(config, "onset", "")

        key = _rule_key(rule)
        with self._lock:
            first_seen = self._first_seen.get(key)
            if first_seen is None:
                first_seen = now_seconds
                self._first_seen[key] = first_seen
        elapsed = max(0.0, now_seconds - first_seen)

        if onset == "gradual":
            start = _clamp(_flt(config, "start_probability", 0.0))
            ramp = max(0.001, _flt(config, "ramp_seconds", 60.0))
            if elapsed >= ramp:
                return _clamp(base)
            frac = elapsed / ramp
            return _clamp(start + (base - start) * frac)

        if onset == "bursty":
            factor = _flt(config, "burst_factor", 2.0)
            if self._in_burst_window(config, now_seconds):
                return _clamp(base * factor)
            return _clamp(base)

        return _clamp(base)

    def retain_only(self, live_rule_keys: Iterable[str]) -> None:
        """Drop first-seen tracking state for rules no longer present, so a
        re-added rule restarts its onset cleanly."""
        live = set(live_rule_keys)
        with self._lock:
            for key in list(self._first_seen.keys()):
                if key not in live:
                    del self._first_seen[key]

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _in_burst_window(config: Dict, now_seconds: float) -> bool:
        """Deterministic burst windows: alternate quiet/burst periods based on a
        configurable cycle. ``burst_period_seconds`` is the full cycle length;
        ``burst_active_seconds`` is how much of each cycle is "bursting"."""
        period = max(1.0, _flt(config, "burst_period_seconds", 30.0))
        active = max(0.0, _flt(config, "burst_active_seconds", 10.0))
        pos_in_cycle = now_seconds % period
        return pos_in_cycle < active


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _rule_key(rule: FaultRuleConfig) -> str:
    return rule.id or rule.fault_type


def _clamp(v: float) -> float:
    if v < 0.0:
        return 0.0
    if v > 1.0:
        return 1.0
    return v


def _str(config: Dict, key: str, default: str) -> str:
    val = config.get(key)
    return str(val) if val is not None else default


def _flt(config: Dict, key: str, default: float) -> float:
    val = config.get(key)
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        try:
            return float(val)
        except ValueError:
            return default
    return default
