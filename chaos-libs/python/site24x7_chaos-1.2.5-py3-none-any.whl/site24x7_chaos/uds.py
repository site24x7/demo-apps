"""Unix Domain Socket client for instant fault-config push + health reporting.

Connects to the agent's UDS at ``/var/site24x7-labs/agent.sock`` for instant
fault-config push and health reporting, replacing file polling when the socket is
available. Runs as a daemon thread: on connect it registers the instance, then
reads newline-delimited JSON messages from the agent (config pushes, kill
commands), and periodically sends health snapshots. If the socket is unavailable
or drops, it backs off and retries; the file-based :class:`ConfigFileWatcher`
continues to work as a fallback meanwhile.

Uses only the Python standard library (``socket`` + ``threading`` + ``json``).
The thread body is fully wrapped in try/except so it can never crash the host
application.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import socket
import threading
from typing import Callable, List, Mapping, Optional

from .models import AppFaultConfig

logger = logging.getLogger("site24x7_chaos.uds")

_DEFAULT_SOCKET_PATH = "/var/site24x7-labs/agent.sock"
_DEFAULT_HEALTH_INTERVAL_S = 10.0
_DEFAULT_RECONNECT_BACKOFF_S = 5.0
_RECV_BUFSIZE = 4096


class UDSClient:
    """Connects to the agent over a Unix Domain Socket in a daemon thread.

    Parameters mirror the Java ``UDSClient`` feature contract.
    """

    def __init__(
        self,
        socket_path: str,
        instance_id: str,
        app_name: str,
        version: str,
        hostname: str,
        pid: int,
        db_drivers: List[str],
        on_config: Callable[[AppFaultConfig], None],
        on_kill: Callable[[], None],
        health_supplier: Callable[[], Mapping[str, object]],
        health_interval_s: float = _DEFAULT_HEALTH_INTERVAL_S,
        reconnect_backoff_s: float = _DEFAULT_RECONNECT_BACKOFF_S,
    ) -> None:
        self._socket_path = socket_path
        self._instance_id = instance_id
        self._app_name = app_name
        self._language = "python"
        self._version = version
        self._hostname = hostname
        self._pid = pid
        self._db_drivers = db_drivers or []
        self._on_config = on_config
        self._on_kill = on_kill
        self._health_supplier = health_supplier
        self._health_interval_s = health_interval_s
        self._reconnect_backoff_s = reconnect_backoff_s

        self._running = False
        self._wake = threading.Event()  # set by stop(): ends any wait at once
        self._thread: Optional[threading.Thread] = None
        self._send_lock = threading.Lock()
        self._sock: Optional[socket.socket] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._running = True
        self._wake.clear()
        self._thread = threading.Thread(
            target=self._run, name="chaos-uds-client", daemon=True
        )
        self._thread.start()
        logger.info("UDS client started, socket: %s", self._socket_path)

    def stop(self) -> None:
        self._running = False
        self._wake.set()
        sock = self._sock
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass

    # ------------------------------------------------------------------
    # Thread body — never allowed to crash the host app
    # ------------------------------------------------------------------

    def _run(self) -> None:
        while self._running:
            try:
                self._connect_and_serve()
            except Exception as exc:  # noqa: BLE001 - must never propagate
                logger.debug("UDS connection ended: %s", exc)
            if not self._running:
                break
            self._wake.wait(self._reconnect_backoff_s)

    def _connect_and_serve(self) -> None:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            sock.connect(self._socket_path)
            self._sock = sock

            # Register this instance.
            self._send(sock, self._register_message())
            logger.info(
                "Connected to agent over UDS at %s (app=%s)",
                self._socket_path,
                self._app_name,
            )

            # Health reporter for the lifetime of this connection.
            health_thread = threading.Thread(
                target=self._health_loop,
                args=(sock,),
                name="chaos-uds-health",
                daemon=True,
            )
            health_thread.start()

            self._read_loop(sock)
        finally:
            self._sock = None
            try:
                sock.close()
            except OSError:
                pass

    def _read_loop(self, sock: socket.socket) -> None:
        """Read newline-delimited JSON messages until the socket closes."""
        buffer = b""
        while self._running:
            try:
                chunk = sock.recv(_RECV_BUFSIZE)
            except OSError:
                break
            if not chunk:
                break  # peer closed
            buffer += chunk
            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n", 1)
                if line.strip():
                    self._handle_message(line.decode("utf-8", "replace"))

    def _handle_message(self, line: str) -> None:
        try:
            msg = json.loads(line)
        except (json.JSONDecodeError, ValueError) as exc:
            logger.debug("Failed to parse UDS message: %s", exc)
            return
        if not isinstance(msg, dict):
            return

        msg_type = msg.get("type")
        try:
            if msg_type == "config":
                config = AppFaultConfig.from_dict(msg)
                if self._on_config is not None:
                    self._on_config(config)
            elif msg_type == "kill":
                if self._on_kill is not None:
                    self._on_kill()
            elif msg_type == "registered":
                logger.debug("Agent acknowledged registration")
            else:
                logger.debug("Unknown UDS message type: %s", msg_type)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Failed to handle UDS message: %s", exc)

    def _health_loop(self, sock: socket.socket) -> None:
        while self._running and self._sock is sock:
            self._wake.wait(self._health_interval_s)
            if self._sock is not sock:
                return
            try:
                health = (
                    dict(self._health_supplier())
                    if self._health_supplier is not None
                    else {}
                )
                self._send(sock, self._health_message(health))
            except Exception as exc:  # noqa: BLE001
                logger.debug("UDS health report failed: %s", exc)
                return  # connection likely dropped; outer loop reconnects

    # ------------------------------------------------------------------
    # Message builders / IO
    # ------------------------------------------------------------------

    def _register_message(self) -> dict:
        return {
            "type": "register",
            "instance_id": self._instance_id,
            "app_name": self._app_name,
            "language": self._language,
            "version": self._version,
            "hostname": self._hostname,
            "pid": self._pid,
            "db_drivers": self._db_drivers,
        }

    def _health_message(self, health: Mapping[str, object]) -> dict:
        return {
            "type": "health",
            "instance_id": self._instance_id,
            "health": dict(health) if health else {},
        }

    def _send(self, sock: socket.socket, msg: dict) -> None:
        data = (json.dumps(msg) + "\n").encode("utf-8")
        with self._send_lock:
            sock.sendall(data)


# ------------------------------------------------------------------
# Module helpers reused by the engine
# ------------------------------------------------------------------

def detect_db_drivers() -> List[str]:
    """Best-effort detection of which DB drivers are importable, so the agent
    knows what DB chaos this instance can absorb. Detection never initializes a
    connection — it only checks importability via ``find_spec``.
    """
    import importlib.util

    drivers: List[str] = []
    probes = [
        ("psycopg2", "postgresql"),
        ("psycopg", "postgresql"),
        ("asyncpg", "postgresql"),
        ("pymysql", "mysql"),
        ("MySQLdb", "mysql"),
        ("mysql.connector", "mysql"),
        ("pymongo", "mongodb"),
        ("redis", "redis"),
    ]
    for module_name, label in probes:
        try:
            if importlib.util.find_spec(module_name) is not None:
                if label not in drivers:
                    drivers.append(label)
        except (ImportError, ValueError, ModuleNotFoundError):
            continue
    return drivers


def current_hostname() -> str:
    try:
        return platform.node() or socket.gethostname()
    except Exception:  # noqa: BLE001
        return os.environ.get("HOSTNAME", "unknown")
