"""Resource / JVM-equivalent fault injector — 6 fault types.

All faults run in daemon threads with a bounded duration so they
self-clean and cannot outlive the process.

Fault types handled
-------------------
1. ``thread_pool_exhaustion`` — Spawn busy-sleeping threads.
2. ``memory_pressure``        — Allocate large bytearrays on the heap.
3. ``cpu_burn``               — Tight math loops across multiple threads.
4. ``gc_pressure``            — Rapid short-lived allocations to stress the GC.
5. ``thread_deadlock``        — Two threads that deadlock on ``threading.Lock``.
6. ``disk_fill``              — Write temp files to consume disk space.

Trigger model
-------------
Unlike HTTP/JDBC/Redis faults, resource faults are **not** triggered per-request.
Instead, the :class:`ResourceFaultInjector` registers as a config-update listener
on the :class:`ChaosEngine`.  When the agent pushes a new config, the injector
checks for active resource rules and fires the first one (only one resource fault
can be active at a time to prevent cascading issues).
"""

from __future__ import annotations

import gc
import logging
import math
import os
import random
import re
import tempfile
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

from ..models import FaultRuleConfig

if TYPE_CHECKING:
    from ..engine import ChaosEngine

logger = logging.getLogger("site24x7_chaos.fault.resource")

# Longest a resource fault runs. Agent experiments (sdk-cpu-pressure etc.) run
# for minutes and stop the fault early by removing its rule, so this is only a
# safety cap for a rule nobody removes.
_MAX_RESOURCE_DURATION_MS = 600_000

_RESOURCE_FAULT_TYPES = frozenset(
    {
        "thread_pool_exhaustion",
        "memory_pressure",
        "cpu_burn",
        "gc_pressure",
        "thread_deadlock",
        "disk_fill",
        "process_exit",
        "log_flood",
        "connpool_exhaust",
        "startup_delay",
        "n_plus_one",
        "full_table_scan",
        "thundering_herd",
        "unbounded_query",
        "connection_leak",
    }
)


class ResourceFaultInjector:
    """Registers as a config-update listener and fires resource faults.

    Usage::

        injector = ResourceFaultInjector(engine)
        injector.install()   # registers the listener
    """

    def __init__(self, engine: ChaosEngine) -> None:
        self._engine = engine
        self._active = threading.Event()
        # The running fault: _stop is set to end it early (rule removed, kill
        # switch, SDK disabled) and _active_rule is the rule it runs for.
        self._run_lock = threading.Lock()
        self._stop: Optional[threading.Event] = None
        self._active_rule = ""

    def install(self) -> None:
        """Register as a config-update listener on the engine."""
        self._engine.add_config_update_listener(self._on_config_update)
        logger.info("ResourceFaultInjector installed")

    # ------------------------------------------------------------------
    # Listener
    # ------------------------------------------------------------------

    def _on_config_update(self) -> None:
        self.evaluate_and_apply()

    def evaluate_and_apply(self) -> None:
        """Check active rules for resource faults and fire the first match."""
        if self._active.is_set():
            # A running fault ends early once its rule is gone: removed by the
            # experiment's revert, cleared by the kill switch, or the SDK disabled.
            if not self._engine.enabled or not self._rule_still_active():
                self._stop_active()
            else:
                logger.debug("Resource fault already active, skipping")
            return

        if not self._engine.enabled:
            return

        rules: List[FaultRuleConfig] = [
            r
            for r in self._engine.active_rules
            if r.fault_type in _RESOURCE_FAULT_TYPES and self._engine.should_fire(r)
        ]

        if not rules:
            return

        rule = rules[0]
        ft = rule.fault_type
        if ft == "thread_pool_exhaustion":
            self._apply_thread_pool_exhaustion(rule)
        elif ft == "memory_pressure":
            self._apply_memory_pressure(rule)
        elif ft == "cpu_burn":
            self._apply_cpu_burn(rule)
        elif ft == "gc_pressure":
            self._apply_gc_pressure(rule)
        elif ft == "thread_deadlock":
            self._apply_thread_deadlock(rule)
        elif ft == "disk_fill":
            self._apply_disk_fill(rule)
        elif ft == "process_exit":
            self._apply_process_exit(rule)
        elif ft == "log_flood":
            self._apply_log_flood(rule)
        elif ft == "connpool_exhaust":
            self._apply_connpool_exhaust(rule)
        elif ft == "startup_delay":
            self._apply_startup_delay(rule)
        elif ft == "n_plus_one":
            self._apply_n_plus_one(rule)
        elif ft == "full_table_scan":
            self._apply_full_table_scan(rule)
        elif ft == "thundering_herd":
            self._apply_thundering_herd(rule)
        elif ft == "unbounded_query":
            self._apply_unbounded_query(rule)
        elif ft == "connection_leak":
            self._apply_connection_leak(rule)
        else:
            logger.warning("Unknown resource fault type: %s", ft)

    # ------------------------------------------------------------------
    # Run bookkeeping
    # ------------------------------------------------------------------

    def _begin(self, rule: FaultRuleConfig) -> threading.Event:
        """Mark a fault as running for rule; returns its stop event."""
        with self._run_lock:
            stop = threading.Event()
            self._stop = stop
            self._active_rule = _rule_key(rule)
            self._active.set()
            return stop

    def _end(self, stop: threading.Event) -> None:
        """Mark the fault started with stop as finished."""
        with self._run_lock:
            if self._stop is not stop:
                return
            self._stop = None
            self._active_rule = ""
            self._active.clear()

    def _stop_active(self) -> None:
        with self._run_lock:
            if self._stop is not None and not self._stop.is_set():
                logger.info("Rule %s removed — stopping its resource fault", self._active_rule)
                self._stop.set()

    def _rule_still_active(self) -> bool:
        with self._run_lock:
            key = self._active_rule
        return any(_rule_key(r) == key for r in self._engine.active_rules)

    # ------------------------------------------------------------------
    # 1. Thread pool exhaustion
    # ------------------------------------------------------------------

    def _apply_thread_pool_exhaustion(self, rule: FaultRuleConfig) -> None:
        thread_count = _clamp(rule.get_config_int("thread_count", 10), 1, 50)
        duration_ms = _clamp(rule.get_config_int("duration_ms", 30000), 1000, _MAX_RESOURCE_DURATION_MS)

        logger.info(
            "Injecting thread pool exhaustion: %d threads for %dms",
            thread_count,
            duration_ms,
        )
        stop = self._begin(rule)

        def orchestrator() -> None:
            barrier = threading.Barrier(thread_count + 1, timeout=duration_ms / 1000.0 + 5)
            workers: list[threading.Thread] = []

            def worker() -> None:
                try:
                    stop.wait(duration_ms / 1000.0)
                finally:
                    try:
                        barrier.wait()
                    except threading.BrokenBarrierError:
                        pass

            try:
                for i in range(thread_count):
                    t = threading.Thread(
                        target=worker,
                        name=f"chaos-thread-exhaust-{i}",
                        daemon=True,
                    )
                    workers.append(t)
                    t.start()
                try:
                    barrier.wait()
                except threading.BrokenBarrierError:
                    pass
                logger.info("Thread pool exhaustion fault completed")
            finally:
                self._end(stop)

        threading.Thread(
            target=orchestrator,
            name="chaos-thread-exhaust-orchestrator",
            daemon=True,
        ).start()

    # ------------------------------------------------------------------
    # 2. Memory pressure
    # ------------------------------------------------------------------

    def _apply_memory_pressure(self, rule: FaultRuleConfig) -> None:
        allocation_mb = _clamp(rule.get_config_int("allocation_mb", 64), 1, 512)
        duration_ms = _clamp(rule.get_config_int("duration_ms", 30000), 1000, _MAX_RESOURCE_DURATION_MS)

        logger.info(
            "Injecting memory pressure: %dMB for %dms",
            allocation_mb,
            duration_ms,
        )
        stop = self._begin(rule)

        def mem_worker() -> None:
            blocks: list[bytearray] | None = None
            try:
                blocks = []
                for i in range(allocation_mb):
                    block = bytearray(1024 * 1024)  # 1 MB
                    # Touch the memory at page boundaries to ensure real allocation
                    for offset in range(0, len(block), 4096):
                        block[offset] = i & 0xFF
                    blocks.append(block)
                logger.debug("Memory pressure: allocated %dMB", allocation_mb)
                stop.wait(duration_ms / 1000.0)
            except MemoryError:
                logger.warning(
                    "Memory pressure: MemoryError during allocation, holding partial"
                )
                stop.wait(duration_ms / 1000.0)
            finally:
                del blocks
                gc.collect()
                self._end(stop)
                logger.info("Memory pressure fault completed, memory released")

        threading.Thread(
            target=mem_worker, name="chaos-memory-pressure", daemon=True
        ).start()

    # ------------------------------------------------------------------
    # 3. CPU burn
    # ------------------------------------------------------------------

    def _apply_cpu_burn(self, rule: FaultRuleConfig) -> None:
        thread_count = _clamp(rule.get_config_int("thread_count", 2), 1, 8)
        duration_ms = _clamp(rule.get_config_int("duration_ms", 30000), 1000, _MAX_RESOURCE_DURATION_MS)

        logger.info(
            "Injecting CPU burn: %d threads for %dms", thread_count, duration_ms
        )
        stop = self._begin(rule)

        end_time = time.monotonic() + duration_ms / 1000.0
        barrier = threading.Barrier(thread_count + 1, timeout=duration_ms / 1000.0 + 5)

        def burner() -> None:
            try:
                x = random.random()
                while time.monotonic() < end_time and not stop.is_set():
                    for _ in range(1000):
                        x = math.sin(x) * math.cos(x)
            finally:
                try:
                    barrier.wait()
                except threading.BrokenBarrierError:
                    pass

        def orchestrator() -> None:
            try:
                for i in range(thread_count):
                    threading.Thread(
                        target=burner,
                        name=f"chaos-cpu-burn-{i}",
                        daemon=True,
                    ).start()
                try:
                    barrier.wait()
                except threading.BrokenBarrierError:
                    pass
                logger.info("CPU burn fault completed")
            finally:
                self._end(stop)

        threading.Thread(
            target=orchestrator,
            name="chaos-cpu-burn-orchestrator",
            daemon=True,
        ).start()

    # ------------------------------------------------------------------
    # 4. GC pressure
    # ------------------------------------------------------------------

    def _apply_gc_pressure(self, rule: FaultRuleConfig) -> None:
        alloc_rate = _clamp(
            rule.get_config_int("allocation_rate_mb_per_sec", 10), 1, 100
        )
        duration_ms = _clamp(rule.get_config_int("duration_ms", 30000), 1000, _MAX_RESOURCE_DURATION_MS)

        logger.info(
            "Injecting GC pressure: %dMB/sec for %dms", alloc_rate, duration_ms
        )
        stop = self._begin(rule)

        def gc_worker() -> None:
            try:
                end_time = time.monotonic() + duration_ms / 1000.0
                sleep_s = max(0.001, 1.0 / alloc_rate)
                while time.monotonic() < end_time and not stop.is_set():
                    # Allocate 1MB — short-lived so the GC must collect it
                    garbage = bytearray(1024 * 1024)
                    garbage[0] = 1
                    garbage[-1] = 1
                    del garbage
                    stop.wait(sleep_s)
                logger.info("GC pressure fault completed")
            except MemoryError:
                logger.warning("GC pressure: MemoryError, stopping early")
            finally:
                self._end(stop)

        threading.Thread(
            target=gc_worker, name="chaos-gc-pressure", daemon=True
        ).start()

    # ------------------------------------------------------------------
    # 5. Thread deadlock
    # ------------------------------------------------------------------

    def _apply_thread_deadlock(self, rule: FaultRuleConfig) -> None:
        duration_ms = _clamp(rule.get_config_int("duration_ms", 30000), 1000, _MAX_RESOURCE_DURATION_MS)

        logger.info("Injecting thread deadlock for %dms", duration_ms)
        stop = self._begin(rule)

        lock_a = threading.Lock()
        lock_b = threading.Lock()
        stop_event = threading.Event()

        def thread_1() -> None:
            lock_a.acquire()
            try:
                time.sleep(0.05)
                # This will block forever (deadlock) until stop_event
                while not stop_event.is_set():
                    if lock_b.acquire(timeout=0.1):
                        try:
                            stop.wait(duration_ms / 1000.0)
                        finally:
                            lock_b.release()
                        break
            finally:
                lock_a.release()

        def thread_2() -> None:
            lock_b.acquire()
            try:
                time.sleep(0.05)
                while not stop_event.is_set():
                    if lock_a.acquire(timeout=0.1):
                        try:
                            stop.wait(duration_ms / 1000.0)
                        finally:
                            lock_a.release()
                        break
            finally:
                lock_b.release()

        def watchdog() -> None:
            try:
                t1 = threading.Thread(
                    target=thread_1, name="chaos-deadlock-1", daemon=True
                )
                t2 = threading.Thread(
                    target=thread_2, name="chaos-deadlock-2", daemon=True
                )
                t1.start()
                t2.start()
                stop.wait(duration_ms / 1000.0)
            finally:
                stop_event.set()
                self._end(stop)
                logger.info("Thread deadlock fault completed")

        threading.Thread(
            target=watchdog, name="chaos-deadlock-watchdog", daemon=True
        ).start()

    # ------------------------------------------------------------------
    # 6. Disk fill
    # ------------------------------------------------------------------

    def _apply_disk_fill(self, rule: FaultRuleConfig) -> None:
        allocation_mb = _clamp(rule.get_config_int("allocation_mb", 64), 1, 512)
        duration_ms = _clamp(rule.get_config_int("duration_ms", 30000), 1000, _MAX_RESOURCE_DURATION_MS)

        logger.info(
            "Injecting disk fill: %dMB for %dms", allocation_mb, duration_ms
        )
        stop = self._begin(rule)

        def disk_worker() -> None:
            temp_files: list[Path] = []
            try:
                tmp_dir = Path(tempfile.gettempdir())
                block = b"\xAA" * (1024 * 1024)  # 1 MB

                for i in range(allocation_mb):
                    fp = tmp_dir / f"chaos-disk-fill-{i}.tmp"
                    fp.write_bytes(block)
                    temp_files.append(fp)

                logger.debug("Disk fill: wrote %dMB of temp files", allocation_mb)
                stop.wait(duration_ms / 1000.0)
            except OSError as exc:
                logger.warning("Disk fill: error during writing: %s", exc)
            finally:
                for fp in temp_files:
                    try:
                        fp.unlink(missing_ok=True)
                    except OSError:
                        pass
                self._end(stop)
                logger.info(
                    "Disk fill fault completed, %d temp files cleaned up",
                    len(temp_files),
                )

        threading.Thread(
            target=disk_worker, name="chaos-disk-fill", daemon=True
        ).start()

    # ------------------------------------------------------------------
    # 7. Process exit
    # ------------------------------------------------------------------

    def _apply_process_exit(self, rule: FaultRuleConfig) -> None:
        delay_seconds = _clamp(rule.get_config_int("delay_seconds", 0), 0, 60)
        exit_code = _clamp(rule.get_config_int("exit_code", 1), 1, 255)

        logger.info(
            "Injecting process exit: exit_code=%d delay=%ds",
            exit_code,
            delay_seconds,
        )
        stop = self._begin(rule)

        def exit_worker() -> None:
            try:
                if delay_seconds > 0:
                    logger.info(
                        "Process exit: waiting %ds before terminating...",
                        delay_seconds,
                    )
                    if stop.wait(delay_seconds):
                        logger.info("Process exit cancelled before it fired")
                        self._end(stop)
                        return
                logger.error(
                    "CHAOS FAULT: Terminating process with exit code %d "
                    "— simulating application crash",
                    exit_code,
                )
                # Use os._exit() for immediate termination without cleanup,
                # mimicking a real crash (not a graceful shutdown).
                os._exit(exit_code)
            except Exception:
                self._end(stop)

        # NOT a daemon thread — must survive to execute the exit
        threading.Thread(
            target=exit_worker, name="chaos-process-exit", daemon=False
        ).start()


    # ------------------------------------------------------------------
    # 8. Log flood — write random bytes to stderr at high rate
    # ------------------------------------------------------------------

    def _apply_log_flood(self, rule: FaultRuleConfig) -> None:
        import sys, random as _rnd
        config = rule.config or {}
        rate_mb = _clamp(int(config.get("rate_mb_per_sec", 5)), 1, 50)
        duration_ms = _clamp(int(config.get("duration_ms", 30000)), 1000, 300000)

        logger.info("Injecting log flood: %dMB/sec for %dms", rate_mb, duration_ms)
        stop = self._begin(rule)
        chunk = bytearray(_rnd.getrandbits(8) for _ in range(1024 * 1024))

        def worker():
            try:
                import time as _t
                deadline = _t.monotonic() + duration_ms / 1000.0
                while _t.monotonic() < deadline and not stop.is_set():
                    for _ in range(rate_mb):
                        chunk[_rnd.randint(0, len(chunk) - 1)] = _rnd.randint(0, 255)
                        sys.stderr.buffer.write(chunk)
                    sys.stderr.buffer.flush()
                    stop.wait(1)
            except Exception:
                pass
            finally:
                self._end(stop)
                logger.info("Log flood fault completed")

        threading.Thread(target=worker, name="chaos-log-flood", daemon=True).start()

    # ------------------------------------------------------------------
    # 9. Connection pool exhaust — open and hold TCP connections
    # ------------------------------------------------------------------

    def _apply_connpool_exhaust(self, rule: FaultRuleConfig) -> None:
        import socket as _socket, time as _t
        config = rule.config or {}
        conn_count = _clamp(int(config.get("connection_count", 50)), 1, 500)
        host = str(config.get("db_host", "localhost"))
        port = _clamp(int(config.get("db_port", 5432)), 1, 65535)
        duration_ms = _clamp(int(config.get("duration_ms", 30000)), 1000, 300000)

        logger.info("Injecting connpool exhaustion: %d connections to %s:%d for %dms",
                    conn_count, host, port, duration_ms)
        stop = self._begin(rule)

        def worker():
            socks = []
            try:
                for i in range(conn_count):
                    try:
                        s = _socket.create_connection((host, port), timeout=2)
                        socks.append(s)
                    except Exception as e:
                        logger.warning("ConnPool: connection %d failed: %s", i, e)
                        break
                logger.info("ConnPool: holding %d connections", len(socks))
                stop.wait(duration_ms / 1000.0)
            except Exception:
                pass
            finally:
                for s in socks:
                    try: s.close()
                    except Exception: pass
                self._end(stop)
                logger.info("ConnPool exhaustion completed, %d connections released", len(socks))

        threading.Thread(target=worker, name="chaos-connpool-exhaust", daemon=True).start()

    # ------------------------------------------------------------------
    # 10. Startup delay — sleep inside the process to simulate slow startup
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # DB registration for app-induced faults
    # ------------------------------------------------------------------

    _db_conn = None  # app-registered DB connection/pool

    def register_db(self, conn) -> None:
        """Register the app's DB connection for app-induced fault injection.
        Works with any PEP 249-compatible connection or pool (psycopg2, mysql-connector, SQLAlchemy).
        Call once at startup: injector.register_db(connection)
        """
        self.__class__._db_conn = conn
        logger.info("[chaos-sdk] DB connection registered for app-induced fault injection")

    def _apply_startup_delay(self, rule: FaultRuleConfig) -> None:
        import time as _t
        config = rule.config or {}
        delay_ms = _clamp(int(config.get("delay_ms", 5000)), 100, 120000)

        logger.info("Injecting startup delay: %dms", delay_ms)
        stop = self._begin(rule)

        def worker():
            try:
                stop.wait(delay_ms / 1000.0)
            except Exception:
                pass
            finally:
                self._end(stop)
                logger.info("Startup delay fault completed (%dms elapsed)", delay_ms)

        threading.Thread(target=worker, name="chaos-startup-delay", daemon=True).start()

    # ------------------------------------------------------------------
    # 11. N+1 query — fetch N rows then do individual lookups
    # ------------------------------------------------------------------

    def _apply_n_plus_one(self, rule: FaultRuleConfig) -> None:
        import time as _t
        db = self.__class__._db_conn
        if db is None:
            logger.warning("[chaos-sdk] n_plus_one: no DB registered — call injector.register_db(conn)")
            return
        config = rule.config or {}
        primary_table = str(config.get("primary_table", "orders"))
        related_table = str(config.get("related_table", "order_items"))
        join_column   = str(config.get("join_column", "order_id"))
        if not _valid_identifiers("n_plus_one", primary_table, related_table, join_column):
            return
        row_count     = _clamp(int(config.get("row_count", 50)), 1, 500)
        duration_ms   = _clamp(int(config.get("duration_ms", 30000)), 1000, 300000)

        logger.info("[chaos-sdk] Injecting N+1 query: %s → %s x%d for %dms",
                    primary_table, related_table, row_count, duration_ms)
        stop = self._begin(rule)

        def worker():
            try:
                deadline = _t.monotonic() + duration_ms / 1000.0
                while _t.monotonic() < deadline and not stop.is_set():
                    try:
                        cur = db.cursor()
                        cur.execute(f"SELECT id FROM {primary_table} LIMIT {row_count}")
                        ids = [row[0] for row in cur.fetchall()]
                        cur.close()
                        for rid in ids:
                            try:
                                c2 = db.cursor()
                                c2.execute(f"SELECT * FROM {related_table} WHERE {join_column} = %s", (rid,))
                                c2.fetchall()
                                c2.close()
                            except Exception: pass
                    except Exception as e:
                        logger.debug("[chaos-sdk] n_plus_one error: %s", e)
                        break
                    stop.wait(0.5)
            finally:
                self._end(stop)
                logger.info("[chaos-sdk] N+1 query fault completed")

        threading.Thread(target=worker, name="chaos-n-plus-one", daemon=True).start()

    # ------------------------------------------------------------------
    # 12. Full table scan — SELECT * with no WHERE clause
    # ------------------------------------------------------------------

    def _apply_full_table_scan(self, rule: FaultRuleConfig) -> None:
        import time as _t
        db = self.__class__._db_conn
        if db is None:
            logger.warning("[chaos-sdk] full_table_scan: no DB registered")
            return
        config = rule.config or {}
        table_name  = str(config.get("table_name", "orders"))
        if not _valid_identifiers("full_table_scan", table_name):
            return
        row_limit   = _clamp(int(config.get("row_limit", 10000)), 100, 1000000)
        duration_ms = _clamp(int(config.get("duration_ms", 30000)), 1000, 300000)

        logger.info("[chaos-sdk] Injecting full table scan: SELECT * FROM %s LIMIT %d for %dms",
                    table_name, row_limit, duration_ms)
        stop = self._begin(rule)

        def worker():
            try:
                deadline = _t.monotonic() + duration_ms / 1000.0
                while _t.monotonic() < deadline and not stop.is_set():
                    try:
                        cur = db.cursor()
                        cur.execute(f"SELECT * FROM {table_name} LIMIT {row_limit}")
                        cur.fetchall()
                        cur.close()
                    except Exception as e:
                        logger.debug("[chaos-sdk] full_table_scan error: %s", e)
                        break
                    stop.wait(0.2)
            finally:
                self._end(stop)
                logger.info("[chaos-sdk] Full table scan fault completed")

        threading.Thread(target=worker, name="chaos-full-table-scan", daemon=True).start()

    # ------------------------------------------------------------------
    # 13. Thundering herd — N concurrent identical queries simultaneously
    # ------------------------------------------------------------------

    def _apply_thundering_herd(self, rule: FaultRuleConfig) -> None:
        import time as _t
        db = self.__class__._db_conn
        if db is None:
            logger.warning("[chaos-sdk] thundering_herd: no DB registered")
            return
        config = rule.config or {}
        table_name   = str(config.get("table_name", "products"))
        if not _valid_identifiers("thundering_herd", table_name):
            return
        concurrency  = _clamp(int(config.get("concurrency", 50)), 2, 500)
        duration_ms  = _clamp(int(config.get("duration_ms", 30000)), 1000, 300000)

        logger.info("[chaos-sdk] Injecting thundering herd: %d concurrent queries on %s for %dms",
                    concurrency, table_name, duration_ms)
        stop = self._begin(rule)

        def worker():
            try:
                deadline = _t.monotonic() + duration_ms / 1000.0
                while _t.monotonic() < deadline and not stop.is_set():
                    threads = []
                    for _ in range(concurrency):
                        def one_query():
                            try:
                                cur = db.cursor()
                                cur.execute(f"SELECT * FROM {table_name} LIMIT 100")
                                cur.fetchall()
                                cur.close()
                            except Exception: pass
                        t = threading.Thread(target=one_query, daemon=True)
                        threads.append(t)
                        t.start()
                    for t in threads:
                        t.join(timeout=5)
                    stop.wait(1.0)
            finally:
                self._end(stop)
                logger.info("[chaos-sdk] Thundering herd fault completed")

        threading.Thread(target=worker, name="chaos-thundering-herd", daemon=True).start()

    # ------------------------------------------------------------------
    # 14. Unbounded query — SELECT * without WHERE or LIMIT
    # ------------------------------------------------------------------

    def _apply_unbounded_query(self, rule: FaultRuleConfig) -> None:
        import time as _t
        db = self.__class__._db_conn
        if db is None:
            logger.warning("[chaos-sdk] unbounded_query: no DB registered")
            return
        config = rule.config or {}
        table_name  = str(config.get("table_name", "orders"))
        if not _valid_identifiers("unbounded_query", table_name):
            return
        duration_ms = _clamp(int(config.get("duration_ms", 30000)), 1000, 300000)

        logger.info("[chaos-sdk] Injecting unbounded query on %s for %dms", table_name, duration_ms)
        stop = self._begin(rule)

        def worker():
            try:
                deadline = _t.monotonic() + duration_ms / 1000.0
                while _t.monotonic() < deadline and not stop.is_set():
                    try:
                        cur = db.cursor()
                        cur.execute(f"SELECT * FROM {table_name}")
                        cur.fetchall()
                        cur.close()
                    except Exception as e:
                        logger.debug("[chaos-sdk] unbounded_query error: %s", e)
                        break
                    stop.wait(0.1)
            finally:
                self._end(stop)
                logger.info("[chaos-sdk] Unbounded query fault completed")

        threading.Thread(target=worker, name="chaos-unbounded-query", daemon=True).start()

    # ------------------------------------------------------------------
    # 15. Connection leak — borrow connections from pool without releasing
    # ------------------------------------------------------------------

    def _apply_connection_leak(self, rule: FaultRuleConfig) -> None:
        import time as _t
        db = self.__class__._db_conn
        if db is None:
            logger.warning("[chaos-sdk] connection_leak: no DB registered")
            return
        config = rule.config or {}
        leak_count  = _clamp(int(config.get("leak_count", 50)), 1, 500)
        duration_ms = _clamp(int(config.get("duration_ms", 30000)), 1000, 300000)

        logger.info("[chaos-sdk] Injecting connection leak: %d connections for %dms", leak_count, duration_ms)
        stop = self._begin(rule)

        def worker():
            leaked = []
            try:
                checkout = getattr(db, 'getconn', None) or getattr(db, 'connect', None)
                release = _conn_releaser(db)
                for i in range(leak_count):
                    if checkout is None or stop.is_set():
                        break
                    # Each checkout gives up after a few seconds: once the pool
                    # is exhausted (the point of the fault) it could otherwise
                    # block forever and the release below would never run.
                    conn = _checkout_with_timeout(checkout, release, 3.0)
                    if conn is None:
                        logger.info("[chaos-sdk] connection_leak: pool exhausted after %d connections", i)
                        break
                    leaked.append(conn)
                logger.info("[chaos-sdk] connection_leak: %d connections leaked", len(leaked))
                stop.wait(duration_ms / 1000.0)
            finally:
                for c in leaked:
                    release(c)
                self._end(stop)
                logger.info("[chaos-sdk] Connection leak fault completed, %d connections returned", len(leaked))

        threading.Thread(target=worker, name="chaos-connection-leak", daemon=True).start()


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _conn_releaser(db):
    """Return a function that gives a checked-out connection back to db.

    psycopg2 pools take connections back with pool.putconn(conn); SQLAlchemy
    and mysql-connector pooled connections return to their pool on close().
    """
    putconn = getattr(db, "putconn", None)

    def release(conn) -> None:
        try:
            if putconn is not None:
                putconn(conn)
            else:
                conn.close()
        except Exception:
            pass

    return release


def _checkout_with_timeout(checkout, release, timeout_s: float):
    """Run checkout() and return its connection, or None if it fails or takes
    longer than timeout_s. A connection that arrives late is released."""
    box: list = []

    def run() -> None:
        try:
            box.append(checkout())
        except Exception:
            box.append(None)

    t = threading.Thread(target=run, name="chaos-conn-checkout", daemon=True)
    t.start()
    t.join(timeout_s)
    if t.is_alive():
        def give_back() -> None:
            t.join()
            if box and box[0] is not None:
                release(box[0])
        threading.Thread(target=give_back, daemon=True).start()
        return None
    return box[0] if box else None


def _rule_key(rule: FaultRuleConfig) -> str:
    return rule.id or rule.fault_type


def _clamp(value: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, value))


# A plain or schema-qualified SQL identifier.
_SQL_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,63}(\.[A-Za-z_][A-Za-z0-9_]{0,63})?$")


def _valid_identifiers(fault: str, *names: str) -> bool:
    """The app-induced DB faults put table/column names from the fault rule into
    SQL text (identifiers cannot be bound as parameters), so anything that is
    not a plain identifier is refused rather than run against the app's DB."""
    for n in names:
        if not _SQL_IDENTIFIER.match(n):
            logger.warning("[chaos-sdk] %s: refusing invalid table/column name %r", fault, n)
            return False
    return True
