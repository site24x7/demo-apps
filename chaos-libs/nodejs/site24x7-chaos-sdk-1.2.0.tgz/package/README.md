# Site24x7 Labs Chaos SDK for Node.js

Inject realistic application-level faults into Node.js/Express and Node.js/Fastify microservices. Faults are controlled from the Site24x7 Labs UI, injected via this SDK embedded in the target app, and captured by Site24x7 APM to showcase its monitoring capabilities.

## Quick Start

### Install

```bash
npm install site24x7-chaos-sdk
```

### Initialize (one line)

**Express:**

```javascript
import express from 'express';
import { initChaos } from 'site24x7-chaos-sdk/express';

const app = express();
initChaos(app);
```

**Fastify:**

```javascript
import Fastify from 'fastify';
import { chaosPlugin } from 'site24x7-chaos-sdk/fastify';

const app = Fastify();
app.register(chaosPlugin);
```

### Set environment variables

```bash
export CHAOS_SDK_ENABLED=true
export CHAOS_SDK_APP_NAME=order-service
export CHAOS_SDK_CONFIG_DIR=/var/site24x7-labs/faults
```

### Mount the shared volume

In Docker Compose, add a shared volume so the agent can write config files and the SDK can read them:

```yaml
services:
  order-service:
    volumes:
      - chaos_config:/var/site24x7-labs/faults:ro
```

That's it. No other code changes required.

## Supported Fault Types (19)

| # | Fault Type | Category | Description |
|---|---|---|---|
| 1 | `http_exception` | Inbound HTTP | Throw a mapped error |
| 2 | `http_latency` | Inbound HTTP | Add artificial latency to requests |
| 3 | `http_error_response` | Inbound HTTP | Return a static error response |
| 4 | `http_connection_reset` | Inbound HTTP | Destroy the socket connection |
| 5 | `http_slow_body` | Inbound HTTP | Stream a response body with inter-chunk delays |
| 6 | `http_client_latency` | Outbound HTTP | Add latency to outbound HTTP calls |
| 7 | `http_client_exception` | Outbound HTTP | Throw an error on outbound calls |
| 8 | `http_client_error_response` | Outbound HTTP | Return a fake error response from outbound calls |
| 9 | `jdbc_exception` | Database | Throw an error before queries |
| 10 | `jdbc_latency` | Database | Add latency before queries |
| 11 | `jdbc_connection_pool_drain` | Database | Hold connections from the pool |
| 12 | `redis_exception` | Redis | Throw an error on Redis commands |
| 13 | `redis_latency` | Redis | Add latency before Redis commands |
| 14 | `thread_pool_exhaustion` | Resource | Spawn blocked async operations |
| 15 | `memory_pressure` | Resource | Allocate large buffers on the heap |
| 16 | `cpu_burn` | Resource | Tight math loops |
| 17 | `gc_pressure` | Resource | Rapid short-lived allocations to stress the GC |
| 18 | `thread_deadlock` | Resource | Deadlocked promises |
| 19 | `disk_fill` | Resource | Write temp files to consume disk space |

## Documentation

See [`docs/integration-guide.md`](docs/integration-guide.md) for the full integration guide.

## Requirements

- Node.js >= 18.0.0
- Express >= 4.0 or Fastify >= 4.0
- Access to the Site24x7 Labs agent shared volume

## License

MIT
